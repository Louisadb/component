import MyComponent from "./src/MyComponent.vue";

export default {
  component: MyComponent,
};
