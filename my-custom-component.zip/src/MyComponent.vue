<template>
  <div>Hello from My Custom Component!</div>
</template>

<script>
export default {
  name: "MyComponent",
};
</script>
